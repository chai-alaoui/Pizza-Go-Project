// Gulp Vars
const argv = require('yargs').argv
const browsersync = require('browser-sync').create()
const del = require('del')
const gulp = require('gulp')
const rename = require('gulp-rename')
const replace = require('gulp-replace')
const ignore = require('gulp-ignore')
const handlebars = require('gulp-compile-handlebars')
const svgsprite = require('gulp-svg-sprite')
const fs = require('fs')
const pkg = JSON.parse(fs.readFileSync('./package.json'))

// Gulp Vars for Assets Dev redesign 2020
const sass = require('gulp-sass')(require('sass'));
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const concat = require('gulp-concat');
const uglify = require('gulp-uglify');
var sourcemaps = require('gulp-sourcemaps');
const spritesmith = require('gulp.spritesmith');

// onError Message
const onError = function (error) {
	notify({
		title: 'Gulp Task Error',
		message: 'Check the console'
	}).write(error);
	console.log(error.toString());
	this.emit('end');
}

// ===================================================
// Tasks
// ===================================================


// Copy new or updated templates
// ===================================================
function templates() {
	return gulp
		.src(['./templates/' + pkg.name + '/**/*', '!./templates/' + pkg.name + '/{partials,partials/**}'])
		//.pipe(gulp.dest('./templates/' + pkg.name + 'x'))
		.pipe(ignore.include('*.html'))
		.pipe(handlebars({}, {
			ignorePartials: true,
			batch: ['./templates/' + pkg.name + '/partials'],
			helpers: {
				ifvalue: function (conditional, options) {
					if (conditional == options.hash.equals) {
						return options.fn(this);
					} else {
						return options.inverse(this);
					}
				},
				parseJSON: function (data, options) {
					return options.fn(JSON.parse(data));
				},
				times: function (start, total, block) {
					var accum = '';
					for (var i = start; i < total; ++i) {
						accum += block.fn(i);
					}
					return accum;
				},
				raw: function (options) {
					return options.fn(this);
				}
			}
		}))
        .pipe(gulp.dest('./webapps/templates/' + pkg.name))
		.pipe(gulp.dest('dist/' + pkg.name + ''));
}

// Build sprite
// ===================================================

function sprite() {
	return gulp
		.src('assets/images/svg/*.svg')
		.pipe(svgsprite({
			mode: {
				symbol: {
					dest: '',
					sprite: 'sprite.svg'
				}
			}
		}))
		.pipe(gulp.dest('./webapps/' + pkg.theme + '/images/custom/'))
}

// JavaScript Concat and Uglify
// ===================================================

function JS() {
	return gulp.src([
		'node_modules/slick-carousel/slick/slick.min.js',
		'templates/'+ pkg.name + '/assets-dev/js/addons/**',
		'templates/'+ pkg.name + '/assets-dev/js/main.js'
		])
		.pipe(sourcemaps.init())
		.pipe(plumber({
			errorHandle: onError
		}))
		.pipe(concat('main.min.js'))
		.on('error', onError)
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/js'))

		// Uglify
		.pipe(uglify())
		.on('error', onError)
		.pipe(sourcemaps.write())
		.pipe(gulp.dest('dist/' + pkg.name + '/js'))

		// Notify
		.pipe(notify({
			title: 'Gulp Task Completed',
			message: 'JavaScript has been compiled'
		}))
};

// SASS Compile
// ===================================================
function SASS() {
	return gulp.src('templates/'+ pkg.name + '/assets-dev/sass/style.scss')
		.pipe(plumber({
			errorHandle: onError
		}))
		.pipe(sass({
			outputStyle: 'expanded'
		}))
		.on('error', onError)

		.pipe(rename('main.css'))
		.pipe(gulp.dest('dist/' + pkg.name + '/css'))
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/css'))

		// Notify
		.pipe(notify({
			title: 'Gulp Task Completed',
			message: 'Styles have been compiled'
		}))
};


// COPY Function
// ===================================================

function copy(done) {
	gulp
		.src('templates/' + pkg.name + '/css/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/css/'))
		.pipe(gulp.dest('dist/' + pkg.name + '' + pkg.name + '/css'))
	gulp
		.src('templates/' + pkg.name + '/data/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/data/'))
	gulp
		.src('templates/' + pkg.name + '/ext/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/ext/'))
	gulp
		.src('templates/' + pkg.name + '/images/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/images/'))
		.pipe(gulp.dest('dist/' + pkg.name + '/images'))
	gulp
		.src('templates/' + pkg.name + '/js/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/js/'))
		.pipe(gulp.dest('dist/' + pkg.name + '/js'))
	gulp
		.src('templates/' + pkg.name + '/json/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/json/'))
		.pipe(gulp.dest('dist/' + pkg.name + '/json'))
	gulp
		.src('templates/' + pkg.name + '/fonts/**/*')
		.pipe(gulp.dest('./webapps/templates/' + pkg.name + '/fonts/'))
		.pipe(gulp.dest('dist/' + pkg.name + '/fonts/'))
	gulp
		.src('templates/' + pkg.name + '/remote/**/*')
		.pipe(gulp.dest('dist/' + pkg.name + '/remote'))
	done()
}

function copySourceCode(done) {
	gulp
		.src('templates/' + pkg.name + '/**/*.html')
		.pipe(gulp.dest('dist/' + pkg.name + '/sourceCode'))

	done()
}

// Browsersync
// ===================================================

function watch() {
	gulp.watch('templates/' + pkg.name + '/**/*.{jpg,png,json,svg,css,js}', gulp.series(copy));
	gulp.watch('templates/' + pkg.name + '/*.html', gulp.series(templates));
	gulp.watch('templates/' + pkg.name + '/assets-dev/sass/**/*.scss', gulp.series(SASS, copy)); // Watch SCSS
	gulp.watch('templates/' + pkg.name + '/assets-dev/js/**/*.js', gulp.series(JS, copy)); // Watch JS
}

function sync(done) {
    browsersync.init({
        server: {
            baseDir: "./webapps/templates/pizza-go-cham/"
        },
        port: 3000, // Optional: Specify a port
        browser: "chrome" // Optional: Specify a browser
    });
    done();
}



function clean() {
	return del('dist')
}

function cleanHtml() {
	return del('dist/' + pkg.name + '/**/*.html');
}

const setup = gulp.parallel(sync, watch)
const build = gulp.series(clean, SASS, JS, copy, cleanHtml)
const buildDev = gulp.series(clean, SASS, JS, templates, copy, copySourceCode)
const spriteSVG = gulp.series(sprite)

exports.spriteSVG = spriteSVG
exports.build = build
exports.default = setup
exports.buildDev = buildDev
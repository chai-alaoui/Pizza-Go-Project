$(function () {
    var ajax = new XMLHttpRequest();
    var svgTimeStamp = new Date();
    var actualTimeStamp = svgTimeStamp.getTime();
    // VAR FOR PROD:
    var pathToSVGSprite = 'https://pizzago-vilzing.eu/images/svg-sprite.svg?t=' + actualTimeStamp;
    // VAR FOR LOCAL TESTING:
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
        pathToSVGSprite = 'http://localhost:3000/images/svg-sprite.svg?t=' + actualTimeStamp;
    }

    ajax.open('GET', pathToSVGSprite, true);
    ajax.onload = function (e) {
        if (ajax.status >= 200 && ajax.status < 300) {
            var div = document.createElement('div');
            div.innerHTML = ajax.responseText;
            div.id = 'svg-container';
            div.classList.add('svg-sprite', 'js-svg-sprite');
            div.style.height = '0px';
            div.style.width = '0px';
            document.body.appendChild(div); // Append the div to the body
            document.body.classList.add('js-svg-sprite-loaded');
        } else {
            console.error('SVG Sprite loading failed:', ajax.statusText);
        }
    };
    ajax.onerror = function () {
        console.error('Error during SVG Sprite AJAX request');
    };
    ajax.send();
});

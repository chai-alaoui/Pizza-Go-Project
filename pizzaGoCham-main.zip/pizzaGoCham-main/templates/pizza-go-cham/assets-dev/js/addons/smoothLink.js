$(function () {
    $(".js-navbar-link").on('click', function (event) {
        if (this.hash !== "") {
            event.preventDefault();

            var hash = this.hash;

            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 800, function () {
                window.location.hash = hash;
            });

            if (window.matchMedia('(max-width: 767.98px)').matches) {
                $('.js-navbar').removeClass('show');
                document.documentElement.classList.remove('menu-is-open')
            }
        }
    });
})
$(function () {
  $(".js-slider").slick({
    infinite: true,
    slidesToShow: 1,
    arrows:false,
    autoplay: true,
    autoplaySpeed: 5000
  });
})


document.addEventListener('DOMContentLoaded', function () {
  const navbarToggle = document.getElementById('navbar-toggle');
  const navbarElement = document.querySelector('.js-navbar');

  navbarToggle.addEventListener('click', function () {
    navbarElement.classList.toggle('show');

    // Toggle the 'menu-is-open' class on the <html> element
    document.documentElement.classList.toggle('menu-is-open');
  });
});

